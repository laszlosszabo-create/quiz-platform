export default function Page(){return <div>diag ok</div>}
