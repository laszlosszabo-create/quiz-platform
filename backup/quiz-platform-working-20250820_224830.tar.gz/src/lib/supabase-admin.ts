// This file is deprecated - use supabase-config.ts instead
// Kept for backward compatibility

import { getSupabaseAdmin } from './supabase-config'

// Legacy export for existing code - will be removed in future version
export const supabaseAdmin = getSupabaseAdmin()
