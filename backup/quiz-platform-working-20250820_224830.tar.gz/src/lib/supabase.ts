// This file is deprecated - use supabase-config.ts instead
// Kept for backward compatibility

export { getSupabaseClient as createClient, supabase } from './supabase-config'
