'use client'

import React from 'react'

export function EmailGate({ quiz, allTranslations, lang, sessionId, onEmailSubmitted }: any) {
  return (
    <div className="p-4">Email gate (responsive demo)</div>
  )
}
