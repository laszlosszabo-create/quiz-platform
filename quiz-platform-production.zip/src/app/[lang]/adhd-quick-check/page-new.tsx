export default function Page() {
  return <h1>Új teszt oldal</h1>
}
