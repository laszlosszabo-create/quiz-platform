import ResponsiveQuiz from './quiz/quiz-client'

export default function Page() {
  return <ResponsiveQuiz />
}
